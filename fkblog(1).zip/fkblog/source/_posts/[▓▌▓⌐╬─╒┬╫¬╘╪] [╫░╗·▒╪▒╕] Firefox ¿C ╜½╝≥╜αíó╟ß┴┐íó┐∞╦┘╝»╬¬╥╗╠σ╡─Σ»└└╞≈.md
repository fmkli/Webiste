---
title: 草博文章转载 [装机必备] Firefox – 将简洁、轻量、快速集为一体的浏览器
comments: false
date: 2021-12-19 20:30:33
tags:
---
<h3>转载声明</h3>
本文由我写在<a href="https://gblog.tech">生草博客</a>上写的

原文地址：<a href="https://gblog.tech/fmkli/firefox-%e4%b8%80%e4%b8%aa%e5%bc%80%e6%ba%90%e7%9a%84%e6%b5%8f%e8%a7%88%e5%99%a8.html" data-wplink-edit="true">https://gblog.tech/fmkli/firefox-%e4%b8%80%e4%b8%aa%e5%bc%80%e6%ba%90%e7%9a%84%e6%b5%8f%e8%a7%88%e5%99%a8.html</a>
<h1>正文</h1>
<del>（mozilla还出了VPN）</del>

Firefox出了电脑版、手机版、IOS版，算是比较全面的辽！

官网介绍如下：
<h2>真正的隐私浏览</h2>
<h3>隐私浏览</h3>
Firefox 会在您上网时拦截追踪器，也能在浏览结束后自动清除浏览记录。
<h3>跟踪保护</h3>
某些广告藏有会跟踪您网络足迹的跟踪器。我们知道这很过分。所以我们威力强大的工具要把这些跟踪器拦截在千里之外。
<h3>更快的页面加载</h3>
拦截那些拖慢上网速度的脚本后，页面载入速度快了44%。百利而无一害。
<h2>生草测评</h2>
<h3>外观 10分</h3>
外观非常好

简洁许多，不像隔壁360，广告给你弹N条
<h3>功能 9分</h3>
这浏览器竟然触发了新版UI的Bilibili主页！

emmm......

算好吧，所有平日用的网站都能打开

不过，我不太喜欢没设首页时进入的浏览器首页

广告是有的，不过！可以调整！

Firefox的访问记录，书签，密码可以通过火狐通行证来同步

而且可以一键同步Google Chrome的书签（搁这抢咕鸽生意捏（汪））

Firefox的功能多样........如“远程调试”“取色器”

总之，功能可以与咕鸽浏览器媲美，就是使用人数的问题比不过咕鸽
<h3>难易程度 简单</h3>
<del>汪汪，我也不想写</del>

总之，适合小白使用
<h2>下载链接</h2>
<h3><a href="https://Mozilla.org/firefox">https://Mozilla.org/firefox</a></h3>
<div>由于官网正常，就不需要上传网盘了（<del>汪汪，懒得上传</del>）</div>
