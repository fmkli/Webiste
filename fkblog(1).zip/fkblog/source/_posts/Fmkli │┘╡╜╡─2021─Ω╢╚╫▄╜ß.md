---
title: Fmkli 迟到的2021年度总结
comments: false
date: 2022-01-07 20:30:33
tags:
---
<!-- wp:paragraph -->

<p>2021年，忙碌又快速的一年</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>博客</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>文章更新（包括旧博客<a href="https://vercel.fmkli.ga/" data-type="URL" data-id="https://vercel.fmkli.ga/">https://vercel.fmkli.ga/</a>）共14篇</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>水文：7篇</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>半水不水文：7篇</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>主页</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>Github提交共<strong>324次</strong></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->

<h3>草</h3>
<!-- /wp:heading -->

<!-- wp:heading {"level":1} -->

<h1>1月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>跨年了，这个月连录三个视频，平平无奇的一个月</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>2月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>放寒假啦</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>录了一个视频</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>春节到来</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>买了个<strong>B站大会员</strong></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>3月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>更新一个视频</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>Mum带我去办理借记银行卡办理服务，绑的<strong>我的身份证</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>平平无奇的一个月</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>4月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>清明节发动态：向以身殉职的，为了国家而牺牲的烈士们默哀</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>回老家被虫咬愣是留了个疤</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>平平无奇的一个月</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>搞了新主页</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>5月</h1>
<!-- /wp:heading -->

<!-- wp:heading {"level":4} -->

<h4>那些媒体的的预言成真了...............袁老，一路走好</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>在Steam购入人生第一个游戏——城市天际线，孩子玩的很开心</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>在Epic免费领到Among Us，孩子玩的更开心</p>
<!-- /wp:paragraph -->

<!-- wp:image {"width":444,"height":592,"sizeSlug":"large"} -->

<figure class="wp-block-image size-large is-resized"><img src="https://q3.a1pic.cn/2022/01/07/rHJi.png" alt="" width="444" height="592"/><figcaption><strong>免费领到太空狼人杀</strong></figcaption></figure>
<!-- /wp:image -->

<!-- wp:paragraph -->

<p>发了一条评论，火了（从此转变半评论区UP）</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>6月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>在Steam夏促入手人类一败涂地，孩子玩的很开心</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>平平无奇的一个月</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>7月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>放暑假咯</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>开新论坛，没做多久就没了</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>更新一个视频</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>8月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>还在暑假</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>白嫖域名：imfmkli.xyz 好像是新网的</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>给<a href="https://yfun.top">Yfun</a>捐赠6.66元，获得主页一份

<!-- wp:paragraph -->

<p>平平无奇的一个月</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>9月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>开学了，跨级成功 :)</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>9/25：孟晚舟，欢迎回家！</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>平平无奇的一个月</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>10月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>祖国生日快乐！</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>新论坛开张，目前还存活（<a href="https://bbs.imfmkli.top">https://bbs.imfmkli.top</a>）</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>入手一块Micro:bit 1.5，孩子玩的很开心</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>放弃<a href="http://blog.fmkli.ga">blog.fmkli.ga</a>，转向<a href="https://fmkli.js.org/blog">fmkli.js.org/blog</a>，使用Jekyll摆弄静态博客</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>平平无奇的一个月</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>11月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>平平无奇的一个月</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->

<h1>12月</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p>重新回归<a href="http://blog.fmkli.ga">blog.fmkli.ga</a>，使用Qoddi搭建WordPress动态博客并沿用至今（感谢 超凡_原罪 也就是<a rel="noreferrer noopener" href="https://gblog.tech" target="_blank">艹博</a>博主帮我完善博客）</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>将主页网站从GH pages切换到Vercel</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p>新闻：Steam主域名被工信部拉黑</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->

<h2>新的一年，继续加油，继续努力，谢谢大家的支持！！！！！</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->

<p></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->

<p></p>
<!-- /wp:paragraph -->
